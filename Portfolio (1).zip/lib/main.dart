import 'package:flutter/material.dart';

void main() {
  runApp(MyPortfolioApp());
}

class MyPortfolioApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'My Portfolio',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: PortfolioScreen(),
    );
  }
}

class PortfolioScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('My Portfolio'),
      ),
      backgroundColor: Color(0xffecb2b2),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Header Section
            Container(
              alignment: Alignment.center,
              padding: EdgeInsets.symmetric(vertical: 20.0),
              child: Column(
                children: [
                  CircleAvatar(
                    radius: 50.0,
                    backgroundImage: NetworkImage(
                      'https://raw.githubusercontent.com/Nyxsolas/me/631043d65b0008263da167014ec3a0ad31874622/Me.jpg?token=BH4OYRYVUGDDHOIDNWMNYADGD7Y2O',
                    ),
                  ),
                  SizedBox(height: 10.0),
                  Text(
                    'Tanushree Singh',
                    style: TextStyle(
                      fontSize: 24.0,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
            // Bio Section
            Column(
              children: [
                Text(
                  'About Me:',
                  style: TextStyle(
                    fontSize: 20.0,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 10.0),
                Text(
                  'Hey there! I\'m currently pursuing my BA Programme with a focus on Computer Applications and Mathematics at the University of Delhi. Excited to share that I recently wrapped up the GDSC Cloud study jam, diving deep into cloud computing technologies. I love tinkering with code, especially in Java, Python, and C++, and I\'ve dabbled a bit in HTML too. Oh, and I\'m thrilled to have snagged a consolation prize in our college\'s Codathon competition! I\'m all about using my coding skills to tackle real-world challenges and spread some positive vibes in the tech world.',
                  style: TextStyle(fontSize: 16.0),
                ),
                SizedBox(height: 20.0),
              ],
            ),
            // Skills Section
            Column(
              children: [
                Text(
                  'Skills:',
                  style: TextStyle(
                    fontSize: 20.0,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 10.0),
                Text(
                  'Collaboration and teamwork\n'
                  'Problem-solving skills\n'
                  'Knowledge in coding languages: Java, Python, C++, HTML',
                  style: TextStyle(
                    fontSize: 16.0,
                  ),
                ),
                SizedBox(height: 20.0),
              ],
            ),
            // Contact Information Section
            Column(
              children: [
                Text(
                  'Contact Me:',
                  style: TextStyle(
                    fontSize: 20.0,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 10.0),
                Text(
                  'Email: tanushreeclg@gmail.com\n'
                  'LinkedIn: https://www.linkedin.com/in/tanu-shree-singh\n' // Correct LinkedIn URL
                  'GitHub: https://github.com/Nyxsolas',
                  style: TextStyle(fontSize: 16.0),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
